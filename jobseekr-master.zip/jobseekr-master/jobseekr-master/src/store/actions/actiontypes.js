export const LOGGED_IN_USER = 'LOGGED_IN_USER';
export const IS_AUTHENTICATED = 'IS_AUTHENTICATED';
export const SAVE_JOBS = 'SAVE_JOBS';
export const APPLIED_JOBS = 'APPLIED_JOBS';
export const GET_JOBS = 'GET_JOBS';
export const IS_ADMIN = 'IS_ADMIN';
export const UPDATE_JOB = 'UPDATE_JOB';
export const LOGOUT_USER = 'LOGOUT_USER';