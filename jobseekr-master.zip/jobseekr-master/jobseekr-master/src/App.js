import React from "react";
import "./App.css";
import Footer from "./components/footer/Footer";
import Header from "./components/Header/Header";
import { Route, Switch } from "react-router-dom";
import Home from "./views/Home/Home";
import Form from "./components/Form/Form";
import Jobs from "./views/Jobs/Jobs";
import SavedJobs from "./views/savedJobs/SavedJobs";
import { connect } from 'react-redux';
import PrivateRoute from './hoc/PrivateRoute';
import PublicRoute from './hoc/PublicRoute';
import AddJob from "./views/AddJob/AddJob";
import AppliedJobs from "./views/appliedJobs/AppliedJobs";

function App(props) {
  return (
    <div className="App">
      <Header />
      <Switch>
        <Route component={Home} path="/" exact />
        <PrivateRoute
          path='/jobs'
          isAuthenticated={props.isAuthenticated}
          component={Jobs} />
        <PrivateRoute
          path='/addjob'
          isAuthenticated={props.isAuthenticated}
          component={AddJob} />
        <PrivateRoute
          path='/appliedjobs'
          isAuthenticated={props.isAuthenticated}
          component={AppliedJobs} />
        <PrivateRoute
          path='/editjob/:id'
          isAuthenticated={props.isAuthenticated}
          component={AddJob} />
        <PublicRoute
          path='/login'
          isAuthenticated={props.isAuthenticated}
          component={Form} />
        <PublicRoute
          path='/signup'
          isAuthenticated={props.isAuthenticated}
          component={Form} />
        <PrivateRoute
          path='/savedjobs'
          isAuthenticated={props.isAuthenticated}
          component={SavedJobs} />
      </Switch>
      <Footer />
    </div>
  );
}


const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated
  }
}

export default connect(mapStateToProps, null)(App);
