import React, { useEffect,useState } from "react";
import { connect } from "react-redux";
import JobPost from "../../components/JobPost/JobPost";
import Axios from 'axios';
import * as actions from '../../store/actions/index';

function SavedJobs(props) {

  const [savedJobs, setSavedJobs] = useState([]);
  useEffect(() => {
    Axios.get(`http://localhost:3000/savedjobs/user/${props.user._id}`)
      .then(response => {
          props.saveJOBS(response.data)
      })
  }, []);

  return (
    <div className="container mt-5 post__container">
      <h4 className="mb-4">Saved Jobs</h4>

      {props.savedJobs.map((post, index) => (
        <JobPost
        key={index}
        title={post.job.jobTitle}
        company={post.job.companyName}
        date={post.job.createdAt}
        responsibility={post.job.responsibility}
        JD = {post.job.jobDescription}
        experience={post.job.experience}
        id={post.job._id}
        />
      ))}
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    savedJobs: state.auth.savedJobs,
    user:state.auth.user,
    jobToBeUpdated:state.auth.jobToBeUpdated
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveJOBS: (job) => dispatch(actions.saveJOBS(job)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SavedJobs);
