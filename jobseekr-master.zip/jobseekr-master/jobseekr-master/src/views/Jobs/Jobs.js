import React, { useEffect, useState } from "react";
import JobPost from "../../components/JobPost/JobPost";
import "./Jobs.css";
import { connect } from "react-redux";
import * as actions from '../../store/actions/index'
import Axios from 'axios';


function Jobs(props) {

  useEffect(() => {
    getJobs();
  }, []);

  const getJobs = () => {
    Axios.get('http://localhost:3000/jobs')
      .then(response => {
        props.getJobsHandler(response.data)
      })
  }

  const deleteJob = (id) => {
    Axios.delete(`http://localhost:3000/jobs/${id}`).then(response => {
      getJobs();
    })
  }



  return (
    <React.Fragment>
      <div class="container post__container mt-5">
        <h4 className="mb-4">JOBS</h4>
        {
          props.jobs.length > 0 && props.jobs.map((post, index) => {
            console.log(post)
            return <JobPost
              key={index}
              title={post.jobTitle}
              company={post.companyName}
              date={post.createdAt}
              responsibility={post.responsibility}
              JD = {post.jobDescription}
              experience={post.experience}
              id={post._id}
              deleteJobHandler={(id) => deleteJob(id)}
            />
          })
        }

      </div>
    </React.Fragment>
  );
}

const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
    savedJobs: state.auth.savedJobs,
    jobs: state.auth.jobs
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getJobsHandler: (jobs) =>
      dispatch(actions.getJobs(jobs)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)
  (Jobs);
