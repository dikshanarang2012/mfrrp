import React, { useState, useEffect } from 'react';
import Axios from 'axios'
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';

const AddJob = (props) => {
    const history = useHistory();
    const [jobTitle, setJobTitle] = useState('');
    const [experience, setExperience] = useState('');
    const [responsibility, setresponsibility] = useState('');
    const [companyName, setcompanyName] = useState('');
    const [jd, setJD] = useState('');


    useEffect(() => {
        if (history.location.pathname.includes('editjob')) {
            if (props.jobToBeUpdated !== null) {
                setJobTitle(props.jobToBeUpdated.title)
                setExperience(props.jobToBeUpdated.experience)
                setresponsibility(props.jobToBeUpdated.responsibility)
                setcompanyName(props.jobToBeUpdated.company)
                setJD(props.jobToBeUpdated.jobDescription)
            }
        }
    }, [props.jobToBeUpdated]);


    // const updateJob = () => {
    //     let payload = {
    //         jobTitle: jobTitle,
    //         responsibility: responsibility,
    //         companyName: companyName,
    //         experience: experience,
    //         jobDescription: jd,
    //         id: Date.now()
    //     }
    //     Axios.post("http://localhost:3000/jobs", payload).then(response => console.log(response));
    // }

    const addJobHandler = (e) => {
        e.preventDefault();

        if (history.location.pathname.includes('editjob')) {
            let payload = {
                jobTitle: jobTitle,
                responsibility: responsibility,
                companyName: companyName,
                experience: experience,
                jobDescription: jd,
            }
            Axios.put(`http://localhost:3000/jobs/${props.jobToBeUpdated.id}`, payload).then(response => {
                history.push('/jobs');
            });

        }
        else {
            let payload = {
                jobTitle: jobTitle,
                responsibility: responsibility,
                companyName: companyName,
                experience: experience,
                jobDescription: jd,
                id: Date.now()
            }
            Axios.post("http://localhost:3000/jobs", payload).then(response => console.log(response));
        }
    }

    return (
        <div className="add__job__Container">
            <form onSubmit={addJobHandler}>
                <div className="form-group">
                    <label for="exampleInputEmail1">Job Title</label>
                    <input type="text" className="form-control" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Job Title" />
                </div>
                <div className="form-group">
                    <label for="exampleInputPassword1">experience</label>
                    <input type="text" className="form-control" value={experience} onChange={(e) => setExperience(e.target.value)} id="exampleInputPassword1" placeholder="experience" />
                </div>
                <div className="form-group">
                    <label for="exampleInputPassword1">responsibility</label>
                    <input type="text" className="form-control" value={responsibility} onChange={(e) => setresponsibility(e.target.value)} id="exampleInputPassword1" placeholder="responsibility" />
                </div>
                <div className="form-group">
                    <label for="exampleInputPassword1">companyName</label>
                    <input type="text" className="form-control" value={companyName} onChange={(e) => setcompanyName(e.target.value)} id="exampleInputPassword1" placeholder="companyName" />
                </div>
                <div className="form-group">
                    <label for="exampleInputPassword1">Job Description</label>
                    <textarea rows="3" type="text" value={jd} onChange={(e) => setJD(e.target.value)} className="form-control" id="exampleInputPassword1" placeholder="Job Description" />
                </div>

                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    );
}

const mapStateToProps = (state) => {
    return {
        savedJobs: state.auth.savedJobs,
        user: state.auth.user,
        jobToBeUpdated: state.auth.jobToBeUpdated
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        // saveJOBS: (job) => dispatch(actions.saveJOBS(job)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AddJob);

