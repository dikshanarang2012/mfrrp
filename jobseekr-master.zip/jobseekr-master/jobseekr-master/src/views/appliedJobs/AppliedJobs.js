import React, { useEffect,useState } from "react";
import { connect } from "react-redux";
import JobPost from "../../components/JobPost/JobPost";
import Axios from 'axios';
import * as actions from '../../store/actions/index';

function AppliedJobs(props) {

  const [savedJobs, setSavedJobs] = useState([]);
  useEffect(() => {
    Axios.get(`http://localhost:3000/appliedjobs/user/${props.user._id}`)
      .then(response => {
          props.appliedJobsHandler(response.data)
      })
  }, []);

  return (
    <div className="container mt-5 post__container">
      <h4 className="mb-4">Applied Jobs</h4>
      {props.appliedJobs.length > 0 && props.appliedJobs.map((post, index) => (
        <JobPost
        key={index}
        title={post.job.jobTitle}
        company={post.job.companyName}
        date={post.job.createdAt}
        responsibility={post.job.responsibility}
        JD = {post.job.jobDescription}
        experience={post.job.experience}
        id={post.job._id}
        />
     ))}
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    appliedJobs: state.auth.appliedJobs,
    user:state.auth.user,
    jobToBeUpdated:state.auth.jobToBeUpdated
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    appliedJobsHandler: (job) => dispatch(actions.appliedJobs(job)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AppliedJobs);
